#!/bin/bash
cd /home/g_user
python3 -u -m http.server --cgi
